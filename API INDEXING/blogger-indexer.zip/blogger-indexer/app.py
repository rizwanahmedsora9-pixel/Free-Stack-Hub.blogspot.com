import os
import json
import datetime

from flask import Flask, render_template, request, redirect, url_for, session, flash
from google.oauth2 import service_account
from google.auth.transport.requests import AuthorizedSession

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INSTANCE_DIR = os.path.join(BASE_DIR, "instance")
KEY_PATH = os.path.join(INSTANCE_DIR, "service_account.json")
HISTORY_PATH = os.path.join(INSTANCE_DIR, "history.json")
os.makedirs(INSTANCE_DIR, exist_ok=True)

SCOPES = [
    "https://www.googleapis.com/auth/indexing",
    "https://www.googleapis.com/auth/webmasters.readonly",
]
INDEXING_ENDPOINT = "https://indexing.googleapis.com/v3/urlNotifications:publish"
INSPECT_ENDPOINT = "https://searchconsole.googleapis.com/v1/urlInspection/index:inspect"

app = Flask(__name__)
# IMPORTANT: change this before deploying anywhere public.
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")


def load_history():
    if os.path.exists(HISTORY_PATH):
        with open(HISTORY_PATH) as f:
            return json.load(f)
    return []


def save_history(history):
    with open(HISTORY_PATH, "w") as f:
        json.dump(history, f, indent=2)


def get_client():
    """Returns (AuthorizedSession, service_account_email) or (None, None)."""
    if not os.path.exists(KEY_PATH):
        return None, None
    try:
        creds = service_account.Credentials.from_service_account_file(KEY_PATH, scopes=SCOPES)
        return AuthorizedSession(creds), creds.service_account_email
    except Exception:
        return None, None


@app.route("/", methods=["GET", "POST"])
def setup():
    if request.method == "POST":
        file = request.files.get("keyfile")
        site_url = request.form.get("site_url", "").strip()

        if not file or not file.filename.endswith(".json"):
            flash("Please upload a valid .json service account key file.", "error")
            return redirect(url_for("setup"))

        file.save(KEY_PATH)
        session["site_url"] = site_url

        client, email = get_client()
        if client is None:
            flash("That file couldn't be read as a valid service account key.", "error")
            os.remove(KEY_PATH)
            return redirect(url_for("setup"))

        flash(f"Connected as {email}", "success")
        return redirect(url_for("dashboard"))

    connected = os.path.exists(KEY_PATH)
    email = None
    if connected:
        _, email = get_client()
        connected = email is not None

    return render_template(
        "index.html",
        connected=connected,
        email=email,
        site_url=session.get("site_url", ""),
    )


@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    client, email = get_client()
    if client is None:
        flash("Connect your service account key first.", "error")
        return redirect(url_for("setup"))

    if request.method == "POST":
        target_url = request.form.get("url", "").strip()
        action = request.form.get("action")
        site_url = request.form.get("site_url", session.get("site_url", "")).strip()
        session["site_url"] = site_url

        if not target_url:
            flash("Enter a URL first.", "error")
            return redirect(url_for("dashboard"))

        history = load_history()
        entry = next((h for h in history if h["url"] == target_url), None)
        if entry is None:
            entry = {
                "url": target_url,
                "pushed_at": None,
                "push_status": None,
                "index_verdict": None,
                "checked_at": None,
            }
            history.insert(0, entry)

        if action == "push":
            try:
                resp = client.post(
                    INDEXING_ENDPOINT,
                    json={"url": target_url, "type": "URL_UPDATED"},
                )
                if resp.status_code == 200:
                    entry["push_status"] = "Pushed successfully"
                else:
                    err = resp.json().get("error", {}).get("message", resp.text)
                    entry["push_status"] = f"Error {resp.status_code}: {err}"
            except Exception as e:
                entry["push_status"] = f"Failed: {e}"
            entry["pushed_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

        elif action == "check":
            if not site_url:
                flash("Enter your Search Console site URL first (in the box above).", "error")
            else:
                try:
                    resp = client.post(
                        INSPECT_ENDPOINT,
                        json={"inspectionUrl": target_url, "siteUrl": site_url},
                    )
                    if resp.status_code == 200:
                        result = resp.json().get("inspectionResult", {}).get("indexStatusResult", {})
                        verdict = result.get("verdict", "UNKNOWN")
                        coverage = result.get("coverageState", "")
                        entry["index_verdict"] = f"{verdict} — {coverage}" if coverage else verdict
                    else:
                        err = resp.json().get("error", {}).get("message", resp.text)
                        entry["index_verdict"] = f"Error {resp.status_code}: {err}"
                except Exception as e:
                    entry["index_verdict"] = f"Failed: {e}"
                entry["checked_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

        save_history(history)
        return redirect(url_for("dashboard"))

    history = load_history()
    return render_template(
        "dashboard.html",
        email=email,
        history=history,
        site_url=session.get("site_url", ""),
    )


@app.route("/disconnect")
def disconnect():
    if os.path.exists(KEY_PATH):
        os.remove(KEY_PATH)
    session.clear()
    flash("Disconnected. Upload a key to reconnect.", "success")
    return redirect(url_for("setup"))


if __name__ == "__main__":
    app.run(debug=True)
