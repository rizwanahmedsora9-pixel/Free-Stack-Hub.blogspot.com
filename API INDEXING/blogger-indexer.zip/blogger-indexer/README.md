# Blogger Indexer Console

A small Flask app to push blog post URLs to Google for indexing, and check
whether they're already indexed — plus an optional fully-automatic script.

## 1. One-time Google Cloud setup

1. Go to console.cloud.google.com → create/select a project.
2. Enable two APIs: **Indexing API** and **Search Console API**.
3. IAM & Admin → Service Accounts → Create service account → create a JSON key
   and download it.
4. In **Google Search Console** (search.google.com/search-console):
   - Settings → Users and permissions → Add user
   - Paste the service account's email (ends in `...iam.gserviceaccount.com`,
     found inside the JSON file as `client_email`)
   - Set permission to **Owner** — the Indexing API specifically requires
     Owner-level access, Full/Restricted is not enough.

## 2. Run the dashboard app

```bash
pip install -r requirements.txt --break-system-packages
python app.py
```

Open the local URL it prints, upload your JSON key, enter your site URL
(your blog's homepage, e.g. `https://freestackhub.blogspot.com/` — must match
exactly how it's added in Search Console), and you're connected.

From the dashboard:
- **Push for indexing** → submits the URL via the Indexing API.
- **Check index status** → asks Search Console's URL Inspection API whether
  it's actually indexed (verdict + coverage state).
- Every submission is kept in a history table so you can see status over time.

## 3. Deploying on PythonAnywhere (matches your usual workflow)

Same as your other Flask apps: push this folder to GitHub, `git clone` it on
PythonAnywhere, set the Web app's working directory and WSGI file to point at
`app.py`, then Reload. Keep updating it the usual way: edit locally, push,
`git pull` on PythonAnywhere, Reload.

## 4. True automation — no clicking at all

`auto_index.py` is a separate script you run on a schedule instead of the
dashboard. It checks your blog's RSS feed for new posts and pushes anything
it hasn't submitted before — nothing to click, ever.

1. Edit the three settings at the top of `auto_index.py` (your feed URL is
   already filled in for freestackhub).
2. On PythonAnywhere: **Tasks** tab → add a new scheduled task, once per hour:
   ```
   python3 /home/yourusername/blogger-indexer/auto_index.py
   ```
3. Every time you publish a new post, it gets picked up and submitted on the
   next run — fully automatic from that point on.

The dashboard app and the scheduled script share the same `instance/service_account.json`,
so you only need to connect once.

## Notes

- The Indexing API has a daily quota (200 requests/day by default) — plenty
  for a normal posting schedule.
- `instance/` holds your key file and history — never commit this folder to
  a public GitHub repo.
