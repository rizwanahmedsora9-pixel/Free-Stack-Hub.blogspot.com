"""
Run this on a schedule (e.g. PythonAnywhere Scheduled Tasks, once every hour)
to automatically push any new blog post to Google for indexing - no manual
clicking needed once it's set up.

How it works:
1. Reads your blog's Atom/RSS feed for the latest posts.
2. Compares each post URL against a local record of what's already been
   submitted (submitted.json, created next to this script).
3. Pushes anything new to the Indexing API and records it, so it's never
   submitted twice.

Setup:
  pip install google-auth requests --break-system-packages   (on PythonAnywhere)

  Edit the three settings below, then add a Scheduled Task on PythonAnywhere:
    python3 /home/yourusername/blogger-indexer/auto_index.py
"""

import os
import json
import requests
from google.oauth2 import service_account
from google.auth.transport.requests import AuthorizedSession

# ---- settings: edit these three ----
KEY_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "instance", "service_account.json")
FEED_URL = "https://freestackhub.blogspot.com/feeds/posts/default?alt=json&max-results=10"
SUBMITTED_LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "instance", "submitted.json")
# --------------------------------------

SCOPES = ["https://www.googleapis.com/auth/indexing"]
INDEXING_ENDPOINT = "https://indexing.googleapis.com/v3/urlNotifications:publish"


def load_submitted():
    if os.path.exists(SUBMITTED_LOG):
        with open(SUBMITTED_LOG) as f:
            return set(json.load(f))
    return set()


def save_submitted(urls):
    with open(SUBMITTED_LOG, "w") as f:
        json.dump(sorted(urls), f, indent=2)


def get_recent_post_urls():
    resp = requests.get(FEED_URL, timeout=20)
    resp.raise_for_status()
    data = resp.json()
    entries = data.get("feed", {}).get("entry", [])
    urls = []
    for entry in entries:
        for link in entry.get("link", []):
            if link.get("rel") == "alternate":
                urls.append(link["href"])
                break
    return urls


def main():
    if not os.path.exists(KEY_PATH):
        print("No service account key found at", KEY_PATH)
        return

    creds = service_account.Credentials.from_service_account_file(KEY_PATH, scopes=SCOPES)
    session = AuthorizedSession(creds)

    already = load_submitted()
    recent = get_recent_post_urls()
    new_urls = [u for u in recent if u not in already]

    if not new_urls:
        print("Nothing new to submit.")
        return

    for url in new_urls:
        resp = session.post(INDEXING_ENDPOINT, json={"url": url, "type": "URL_UPDATED"})
        if resp.status_code == 200:
            print("Submitted:", url)
            already.add(url)
        else:
            print("Failed:", url, resp.status_code, resp.text)

    save_submitted(already)


if __name__ == "__main__":
    main()
